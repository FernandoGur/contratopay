# Handoff — Redesign visual ContratoPay ("Elegant SaaS / v5")

Pacote de **mudanças visuais** prontas para a branch `design`. Nada aqui toca a
lógica — `src/lib/` permanece intacto. Os arquivos abaixo espelham os caminhos
do repositório: é só copiar por cima.

## O que mudou (direção)

SaaS premium, neutros frios + acento **índigo (iris)**, verde reservado para
"valor/recebido". Tokens carregam ~80% do reskin — todo componente que usa
`brand-*`, `ink-*`, `.card`, `.bg-brand-gradient` é atualizado automaticamente.

- **Paleta**: azul vivo → **índigo** `#5b5bd6` (primário) com gradiente
  `#6366f1 → #5b5bd6`; neutros agora frios (hairline `#ecedf1`).
- **Tipografia**: display **Inter Tight** (era Plus Jakarta Sans); UI Inter.
- **Raios** mais contidos (cards 12px) e **sombras** sutis em camadas.
- **Botão primário** com gradiente + brilho interno (registro "Stripe-like").
- **Inputs** brancos com foco em anel índigo.
- **AdminLayout**: sidebar com busca **⌘K**, navegação com ativo índigo suave,
  card de usuário com avatar/iniciais; marca textual **ContratoPay** (sem símbolo).
- **Login**: wordmark + botão gradiente.
- Fundo do app passa de "véu azul" para **canvas frio limpo** (`#f8f9fb`).

## Arquivos

| Copiar para | O quê |
|---|---|
| `index.html` | Fontes Inter + Inter Tight |
| `src/index.css` | **Tokens** (cores, fontes, raios, sombras, `.card`, `.bg-brand-gradient`) |
| `src/components/ui.tsx` | Button (gradiente), Input/Select/Textarea (branco), Badge, StatCard |
| `src/components/AdminLayout.tsx` | Shell do vendedor (sidebar + busca + user) |
| `src/pages/Login.tsx` | Tela de login |
| `src/pages/client/ClientArea.tsx` | **Início do cliente redesenhada** (hero com anel + composição da carteira + chips de data) |

### Área do cliente — Início (redesenho premium)

A tela inicial do cliente foi reestruturada (só a aba **Início** — as demais abas e
toda a lógica seguem idênticas):

- O eyebrow + título + card "Andamento" + 3 StatCards viraram **um hero único**:
  **anel de progresso** (% quitado) + Saldo / Já pago / Próxima alinhados com
  divisórias.
- **Barra de composição da carteira** (Pago vs Em aberto, com "Amortizado" quando > 0)
  — o "momento visual" que faltava, alimentado pelos valores reais de `state`.
- **Próximas parcelas** agora com **chips de data** (dia + mês), "Próxima" destacada e
  selo de reajuste IPCA na parcela corrigida.
- Removidos o import `StatCard` e a variável `paidCount` (ficaram sem uso na aba).
  O `<linearGradient id="cp-ring">` é local ao SVG do anel.

`Dashboard`, `Contracts`, `ContractDetail`, `Clients` e a **área do cliente**
herdam o novo visual automaticamente (usam os tokens + componentes acima) — não
precisam de edição para refletir a nova identidade.

## Como aplicar

```bash
git checkout -b design        # se ainda não estiver na branch
# copie os arquivos de handoff/ por cima dos originais
npm run build                 # build deve ficar verde
npx tsx scripts/validate.ts   # deve dar 19 OK, 0 FAIL (lógica intacta)
git commit -am "redesign visual: elegant SaaS (índigo)"
git push -u origin design
# abra o PR — o Cloudflare gera a URL de preview da branch
```

## Pendências / follow-ups (cosméticos, opcionais)

- **QR Code do Pix**: no mock aprovado havia um QR no módulo de pagamento. Não foi
  incluído no código por enquanto porque exige gerar o QR real a partir do payload
  Pix (copia-e-cola) — um QR decorativo seria enganoso. Quando quiser, plugo uma lib
  de geração (ex.: `qrcode`) e ligo à chave ativa.

- **Marca**: ficou com **wordmark** ("Contrato" + "Pay" índigo), sem símbolo —
  placeholder combinado até definirmos um logo. Quando houver um SVG de marca,
  dá para plugar na sidebar/login e gerar favicon.
- **Header da área do cliente** (`src/pages/client/ClientArea.tsx`) ainda mostra
  um monograma com a letra **"R"**. Já está índigo (herda o gradiente), mas o
  ideal é trocar por wordmark ou pela inicial certa — mudança de 1 linha. Posso
  fazer no próximo passo.
- A tabela de contratos do v5 (avatares + status pills) é uma evolução opcional
  da listagem atual — posso portar se você curtir.

## Referência visual

O alvo aprovado é o `ContratoPay Redesign v5.dc.html`. Abra para comparar
pixel a pixel enquanto valida o resultado no preview da branch.
